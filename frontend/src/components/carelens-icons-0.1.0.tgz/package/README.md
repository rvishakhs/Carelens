# @carelens/icons

Typed React icon components for CareLens, generated from SVG source and organized by care category. Ships one component per icon plus a `<CareIcon name="..." />` registry component for data-driven usage (e.g. rendering an `icon_name` column straight from the backend).

## Adding an icon

1. Drop the SVG into `svgs/<category>/<icon-name>.svg` (kebab-case filename becomes the registry key, e.g. `oral-hygiene.svg` → `"oral-hygiene"`).
2. Categories map to folder names:

   | folder               | category key      |
   | -------------------- | ------------------ |
   | `personal-care`      | `personalCare`      |
   | `nutrition`           | `nutrition`         |
   | `hydration`           | `hydration`         |
   | `mobility`             | `mobility`          |
   | `toileting`            | `toileting`         |
   | `medical`              | `medical`           |
   | `communication`        | `communication`     |
   | `activities`           | `activities`        |
   | `emotional-support`    | `emotionalSupport`  |
   | `sleeping`             | `sleeping`          |
   | `processes`            | `processes`         |

3. Run `npm run generate`. This regenerates everything under `src/icons/**` — those files are auto-generated, never hand-edit them.
4. Run `npm run typecheck` (catches duplicate keys, unknown category folders, malformed SVG) and `npm run build`.

Icon keys must be unique across *all* categories, not just within one folder — the generator throws if two SVGs produce the same key.

## Usage

```tsx
import { CareIcon } from "@carelens/icons";

<CareIcon name="bath" size={48} />
```

Or import a specific component directly (better for tree-shaking if you only use a handful of icons):

```tsx
import { BathIcon } from "@carelens/icons";

<BathIcon size={48} />
```

Every icon accepts `size` (default `24`) plus any standard SVG props (`className`, `style`, `onClick`, ...).

### Category colors

```tsx
import { careCategories, careIconCategories } from "@carelens/icons";

const color = careCategories[careIconCategories["bath"]]; // "#14B8A6"
```

### Driving icons from the backend

Store `icon_name` (e.g. `"bath"`, `"oral-hygiene"`) on your activity records and render directly:

```tsx
<CareIcon name={activity.icon_name} />
```

`CareIcon` warns to the console (dev only) and renders nothing if the name doesn't match a registered icon, so a stale/typo'd DB value degrades gracefully instead of crashing.

## Project layout

```
svgs/<category>/*.svg        raw source icons (hand-authored/exported, tracked in git)
scripts/generate-icons.ts    svg -> tsx codegen (npm run generate)
src/icons/**                 GENERATED — one .tsx per icon + registry index.ts
src/CareIcon.tsx             <CareIcon name="..." /> lookup component
src/categories.ts            careCategories color map
src/types.ts                 shared IconProps
src/index.ts                 public API surface
dist/                        build output (npm run build), not committed
```

## Scripts

- `npm run generate` — regenerate `src/icons/**` from `svgs/**`
- `npm run typecheck` — `tsc --noEmit`
- `npm run build` — generate + bundle (ESM + CJS + `.d.ts`) via tsup
- `npm run dev` — tsup in watch mode (does not re-run `generate`; re-run it manually after adding icons)

## Later: React Native

Components currently render a plain `<svg>` (DOM), so this package as-is only works on web. When you're ready for React Native, add a second entry point (e.g. `src/index.native.ts` backed by `react-native-svg`) built from the same `svgs/**` source — the codegen script's SVG parsing/naming logic is reusable, only the component template (`scripts/generate-icons.ts`) needs a React Native variant.
